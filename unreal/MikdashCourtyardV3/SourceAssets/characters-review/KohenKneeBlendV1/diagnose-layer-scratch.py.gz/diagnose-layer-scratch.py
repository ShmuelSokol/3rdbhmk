import sys,json
from pathlib import Path
import numpy as np
root=Path(r'C:/Mikdash/Working-5.8/MikdashCourtyardV3');sys.path.insert(0,str(root/'Scripts'))
import create_kohen_gadol_v1 as K
import measure_kohen_garment_clearance as M
P=K.Parts();K.ketonet(P);K.meil(P);parts={p['name']:p for p in P.parts};bones=M.C.skeleton();index={b['name']:i for i,b in enumerate(bones)}
rv,rj,rw=M.skin_arrays(parts['Ketonet'],K.influence,index);ov,oj,ow=M.skin_arrays(parts['Meil'],K.influence,index)
faces,wall,hem,onring=M.loft_triangles(parts['Meil'],K.MEIL_SEGMENTS);sign=M.tube_signs(ov,wall)
rig=M.Rig(M.CLIPS[0][1],M.CLIPS[0][2]);A,b=M.joint_affines(rig,rig.pose(71/240),bones);R=M.skin(rv,rj,rw,A,b);O=M.skin(ov,oj,ow,A,b);tri=O[wall]
a,bb,c=tri[:,0],tri[:,1],tri[:,2];n=np.cross(bb-a,c-a);n/=np.maximum(np.linalg.norm(n,axis=1),1e-12)[:,None]
rows=[]
for vid in [4260,4262]:
 p=R[vid];dp=np.einsum('mi,mi->m',p-a,n);proj=p-dp[:,None]*n
 inside=np.logical_and.reduce([np.einsum('mi,mi->m',np.cross(bb-a,proj-a),n)>=0,np.einsum('mi,mi->m',np.cross(c-bb,proj-bb),n)>=0,np.einsum('mi,mi->m',np.cross(a-c,proj-c),n)>=0])
 dist=np.where(inside,np.abs(dp),np.inf)
 for u,v in [(a,bb),(bb,c),(c,a)]:dist=np.minimum(dist,M._seg(p[None,None,:],u,v)[0])
 k=int(dist.argmin());corners=wall[k]; segment=vid%K.KETONET_SEGMENTS
 match=[i for i in range(segment,onring,K.MEIL_SEGMENTS) if abs(ov[i,2]-rv[vid,2])<1e-8];assert len(match)==1;mi=match[0]
 rows.append(dict(vertex=vid,rest=rv[vid].tolist(),posed=p.tolist(),signedDistance=float(np.sign(dp[k])*sign[k]*dist[k]),nearestFace=k,faceVertexIds=corners.tolist(),faceRest=ov[corners].tolist(),facePosed=O[corners].tolist(),matchingOuterVertex=mi,matchingOffsetPosed=(O[mi]-p).tolist(),offsetDotFaceNormal=float(np.dot(O[mi]-p,n[k]*sign[k])),matchingWeightsEqual=bool(np.array_equal(rj[vid],oj[mi]) and np.allclose(rw[vid],ow[mi])),faceArea=float(np.linalg.norm(np.cross(bb[k]-a[k],c[k]-a[k]))*.5)))
print(json.dumps(rows,indent=2))
