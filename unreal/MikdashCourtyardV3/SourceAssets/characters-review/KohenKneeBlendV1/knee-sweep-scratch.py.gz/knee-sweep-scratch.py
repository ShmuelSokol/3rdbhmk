import sys,json,time,hashlib
from pathlib import Path
root=Path(r'C:/Mikdash/Working-5.8/MikdashCourtyardV3');sys.path.insert(0,str(root/'Scripts'))
import create_kohen_gadol_v1 as K
import study_kohen_meil_clearance as S
rows=[];before=(K.KNEE_TOP,K.KNEE_BOT)
try:
 for top,bot in [(52,30),(65,20),(74,21),(60,10)]:
  K.KNEE_TOP,K.KNEE_BOT=top,bot
  for t in [71/240,65/240,280/240]:
   r=S.measure(2.2,t);r.update(kneeTop=top,kneeBottom=bot);rows.append(r)
   print(top,bot,t,r['maximumCm'],flush=True)
finally:K.KNEE_TOP,K.KNEE_BOT=before
out=root/'SourceAssets/characters-review/KohenKneeBlendV1';out.mkdir()
(out/'selected-pose-diagnostic.json').write_text(json.dumps(dict(scope='Selected-pose outer-layer diagnostic only; no source geometry change or acceptance',generatorSha256=hashlib.sha256(Path(K.__file__).read_bytes()).hexdigest(),rows=rows),indent=2)+'\n')
