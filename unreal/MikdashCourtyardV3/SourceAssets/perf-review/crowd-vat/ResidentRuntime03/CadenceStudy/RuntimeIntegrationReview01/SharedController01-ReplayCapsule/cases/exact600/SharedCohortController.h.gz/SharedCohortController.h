#pragma once
#include "TravellingCohortStudy.h"
#include "WaitTurnStudy.h"
namespace SharedCohortControllerReview {
template<class Port> void Visit(Port& Adapter) {
using namespace MikdashCrowd;using namespace MikdashCrowdGroups;using namespace CadenceRecoveryStudy;
    auto& Recovery=Adapter.r_Recovery;
    auto& Cause=Adapter.r_Cause;
    auto& Member=Adapter.r_Member;
    auto& Idle=Adapter.r_Idle;
    auto& DrainVisits=Adapter.r_DrainVisits;
    auto& Members=Adapter.r_Members;
    auto& People=Adapter.r_People;
    auto& Now=Adapter.r_Now;
    auto& Gate=Adapter.r_Gate;
    auto& Standing=Adapter.r_Standing;
    auto& Travel=Adapter.r_Travel;
    auto& Party=Adapter.r_Party;
    auto& Config=Adapter.r_Config;
    auto& Seed=Adapter.r_Seed;
    auto& Journey=Adapter.r_Journey;
    auto& Fault=Adapter.r_Fault;
    auto& Horizon=Adapter.r_Horizon;
    auto& PeerGoalWaitVisits=Adapter.r_PeerGoalWaitVisits;
    auto& WaitTurn=Adapter.r_WaitTurn;
    auto& Elapsed=Adapter.r_Elapsed;
    auto& FrameSeconds=Adapter.r_FrameSeconds;
    auto& A=Adapter.r_A;
    auto& MaxYaw=Adapter.r_MaxYaw;
    auto& WaitYawVisits=Adapter.r_WaitYawVisits;
    auto& TurnVisits=Adapter.r_TurnVisits;
    auto& From=Adapter.r_From;
    auto& Expect=Adapter.r_Expect;
    auto& Spacing=Adapter.r_Spacing;
    auto& Id=Adapter.r_Id;

                    if(Recovery.State==Phase::Blocked){Cause[Member]=9;Idle();return;}
                    if(Recovery.State==Phase::Draining)
                    {
                        Cause[Member]=8;Idle();++DrainVisits;bool Drained=true;
                        for(int I=0;I<Members;++I)if(People[I].Walking)Drained=false;
                        if(!Drained)return;
                        Recovery.State=Phase::Selecting;
                    }
                    bool AllReady=true;Vec2 Common[MaxMembers];
                    for(int I=0;I<Members;++I)
                    {
                        Common[I]=People[I].Motion.At(Now);
                        if(People[I].Walking||Length(Common[I]-Recovery.Goals[I])>=25)AllReady=false;
                    }
                    const auto FormationGate=[&](Vec2 A0,Vec2 B0)
                    {
                        if(!Gate(A0,B0))return false;
                        for(Vec2 S:Standing)if(ReservationDistance({A0,B0,0,1},{S,S,0,0},0)<80)return false;
                        return true;
                    };
                    if(AllReady&&!Travel.Active)
                    {
                        Expect(Steering(Party,0,Common,0,{1,0},Config,Seed).MaxLag<=Config.SlowLagCm,
                            "initial regroup barrier remains before travelling phase");
                        Travel.Begin(Members,Recovery.Goals);++Recovery.Completions;Journey.FormationHeading=0;
                    }
                    if(Travel.Active)
                    {
                        if(!Travel.Update(Common,Recovery.Goals,Config.SlowLagCm,FormationGate))
                        {Cause[Member]=9;Recovery.State=Phase::Blocked;Idle();return;}
                        Recovery.ForwardLegs=Travel.Legs-1;
                        Expect(Travel.Anchors.size()<=3,"travelling route cache bounded to two legs");
                    }
                    const auto FrozenGate=[&](Vec2 P,Vec2 Q)
                    {
                        if(Fault==1||!Gate(P,Q))return false;
                        const MotionReservation Probe{P,Q,0,1};
                        for(int I=0;I<Members;++I)if(I!=Member)
                        {
                            // Preserve committed endpoint holds in guidance.
                            // Actual moving intervals are checked by CanReserve.
                            const Vec2 Peer=People[I].Motion.To;
                            if(ReservationDistance(Probe,{Peer,Peer,0,0},0)<80)return false;
                        }
                        for(Vec2 Peer:Standing)if(ReservationDistance(Probe,{Peer,Peer,0,0},0)<80)return false;
                        return true;
                    };
                    const int BeforePlans=Recovery.Plans,BeforeUnplayable=Recovery.Unplayable;
                    const bool Prepared=Recovery.Prepare(Member,From,90*Horizon,FrozenGate);
                    Expect(Recovery.Plans-BeforePlans<=1&&Recovery.PeakExpanded<=DetourRoutingStudy::Nodes,
                        "one bounded A-star search per scheduled visitor visit");
                    if(!Prepared)
                    {
                        Cause[Member]=Length(Recovery.Goals[Member]-From)<25?(Travel.Active?11:2):(Recovery.Unplayable>BeforeUnplayable?7:6);
                        if(Travel.Active&&Cause[Member]==6&&Gate(Recovery.Goals[Member],Recovery.Goals[Member]))
                        {
                            bool PeerHoldsGoal=false;
                            for(int I=0;I<Members;++I)if(I!=Member&&Length(Recovery.Goals[Member]-People[I].Motion.To)<80)PeerHoldsGoal=true;
                            if(PeerHoldsGoal)
                            {
                                ++PeerGoalWaitVisits;
                                const int S=Travel.Segment[Member];
                                const int AbsoluteLeg=static_cast<int>(Travel.Base/400)+S;
                                const double Desired=YawDegrees(Travel.Anchors[S+1]-Travel.Anchors[S]);
                                const double Turn=Clamp(std::max(std::min(Elapsed,FrameSeconds),1.0/120.0),0.0,.5);
                                const double NextYaw=WaitTurn[Member].Turn(AbsoluteLeg,Desired,A.Yaw,Turn);
                                const double Change=std::abs(WrapDegrees(NextYaw-A.Yaw));
                                Expect(Change<=90*std::min(Turn,.25)+1e-8,"waiting turn keeps existing per-frame yaw allowance");
                                MaxYaw=std::max(MaxYaw,Change);
                                if(Change>1e-8){Cause[Member]=13;++WaitYawVisits;++TurnVisits;}
                                A.Yaw=NextYaw;
                                Expect(Length(A.Motion.At(Now)-From)<1e-8,"waiting orientation grants no displacement");
                            }
                        }
                        Idle();bool AllFailed=true;
                        for(int I=0;I<Members;++I)
                            if(Length(Recovery.Goals[I]-Common[I])>=25&&Recovery.Members[I].FailedRevision!=Recovery.Revision)AllFailed=false;
                        // Reached peers may hold; every unfinished peer must
                        // have failed against the same endpoint revision.
                        bool Unfinished=false;
                        for(int I=0;I<Members;++I)if(Length(Recovery.Goals[I]-Common[I])>=25)Unfinished=true;
                        if(Unfinished&&AllFailed)Recovery.State=Phase::Blocked;
                        return;
                    }
                    auto& Track=Recovery.Members[Member];
                    const double Desired=YawDegrees(Track.Target-From);
                    const double Turn=Clamp(std::max(std::min(Elapsed,FrameSeconds),1.0/120.0),0.0,.5);
                    const double Heading=SteerHeading(A.Yaw,Desired,Turn,90);
                    const double Change=std::abs(WrapDegrees(Heading-A.Yaw));
                    MaxYaw=std::max(MaxYaw,Change);++TurnVisits;
                    Expect(Change<=90*std::min(Turn,.25)+1e-8,"route follower preserves frame yaw allowance");
                    A.Yaw=Heading;
                    if(std::abs(WrapDegrees(Desired-Heading))>=1e-7)
                    {Cause[Member]=3;++Recovery.YawOnly;Idle();return;}
                    if(!A.Walking&&Now-A.IdleSince<1){Cause[Member]=4;++Recovery.Dwell;return;}
                    if(!Gate(From,Track.Target)||!Spacing.CanReserve(Id,From,Track.Target,Now,Horizon))
                    {Cause[Member]=5;++Recovery.ReservationWaits;Idle();return;}
                    if(Travel.Active)
                    {
                        MotionReservation Prospective[MaxMembers];
                        for(int I=0;I<Members;++I)Prospective[I]=People[I].Motion;
                        Prospective[Member]={From,Track.Target,Now,Now+Horizon};
                        if(!Travel.Within(Prospective,Now,Config.WaitLagCm))
                        {Cause[Member]=10;++Travel.FormationRefusals;Idle();return;}
                    }
                    const double ActualSpeed=Length(Track.Target-From)/Horizon;
                    Expect(std::abs(VatPlayableSpeed(ActualSpeed,119.95,1,.45,1.55)-ActualSpeed)<1e-6,
                        "coalesced route uses unchanged clip range and full horizon");
                    Expect(Spacing.Reserve(Id,From,Track.Target,Now,Horizon),"independent follower reservation preserves moving peers and endpoints");
                    Cause[Member]=0;A.Walking=true;A.Motion={From,Track.Target,Now,Now+Horizon};Recovery.Reserved(Member);
                    return;
                
}
}
